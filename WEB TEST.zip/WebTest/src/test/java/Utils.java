// Configuration class for Form Automation project

public class Utils {
    final static String BASE_URL = "https://www.saucedemo.com/v1/";
    final static String CHROME_DRIVER_LOCATION = "chromedriver";

}