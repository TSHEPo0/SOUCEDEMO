import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class TestPlan {
    private static final WebDriver driver = new ChromeDriver();

    @BeforeSuite
    public static void main(String[] args) {
        // ChromeDriver location set up in Utils class
        System.setProperty("web-driver.chrome.driver", Utils.CHROME_DRIVER_LOCATION);
    }

    @Test(testName = "Login")
    public static void purchase() throws InterruptedException {
        driver.get(Utils.BASE_URL);
        driver.manage().window().maximize();
        SauceDemoElements sauceDemoElements = new SauceDemoElements(driver);


        //LOG IN PART
        sauceDemoElements.enterUserName();
        Thread.sleep(1000);
        sauceDemoElements.enterPassword();
        Thread.sleep(1000);
        sauceDemoElements.pressSubmitButton();
        Thread.sleep(2000);

        //ADD TO CART PART
        sauceDemoElements.pressAddToCartButton();
        Thread.sleep(1000);
        sauceDemoElements.pressCartButton();
        Thread.sleep(1000);
        sauceDemoElements.pressCheckOutButton();
        Thread.sleep(2000);

        //FILLING UP DETAILS PART
        sauceDemoElements.enterFirstName();
        Thread.sleep(1000);
        sauceDemoElements.enterLastName();
        Thread.sleep(1000);
        sauceDemoElements.enterPostCode();
        Thread.sleep(2000);
        sauceDemoElements.pressContinueOn();
        Thread.sleep(2500);
        sauceDemoElements.pressFinish();
        Thread.sleep(7000);
        sauceDemoElements.clickFinishWord();


    }

    @AfterSuite
    public static void cleanUp(){
        driver.manage().deleteAllCookies();
        driver.close();
    }
}