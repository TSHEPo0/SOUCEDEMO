import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class PojectModel {
    protected WebDriver driver;

    public PojectModel(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
}