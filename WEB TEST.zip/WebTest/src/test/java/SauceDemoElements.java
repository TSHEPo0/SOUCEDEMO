// Page URL: https://www.saucedemo.com/v1/
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SauceDemoElements extends PojectModel{

    //--variables--//
    private final String username = "standard_user";
    private final String pass = "secret_sauce";

    //--//

    private final String fname = "Tshepo";
    private final String fani = "Milanzi";
    private final String code = "1804";
    //-------/-----/-------//


    //LOG IN PART ///

    @FindBy(id = "user-name")
    private WebElement userName;
    @FindBy(id = "password")
    private WebElement password;
    @FindBy(id = "login-button")
    private WebElement login_button;


    //ADDING TO CART PART///

    @FindBy(xpath = "//*[@id=\"inventory_container\"]/div/div[1]/div[3]/button")
    private WebElement add_to_cart_button;
    @FindBy(id = "shopping_cart_container")
    private WebElement open_cart;
    @FindBy(linkText = "CHECKOUT")
    private WebElement check_out;


    // FILLING UP DETAILS PART//

    @FindBy(id = "first-name")
    private WebElement name_one;
    @FindBy(id = "last-name")
    private WebElement surname;
    @FindBy(id = "postal-code")
    private WebElement post_code;
    @FindBy(xpath = "//*[@id=\"checkout_info_container\"]/div/form/div[2]/input")
    private WebElement cont;
    @FindBy(linkText = "FINISH")
    private WebElement finish;
    @FindBy(xpath = "//*[@id=\"contents_wrapper\"]/div[2]")
    private WebElement done;


    ///**************************************************************************************************///
    public SauceDemoElements(WebDriver driver) {
        super(driver);
    }
    ///**************************************************************************************************///


    public void enterUserName(){
        this.userName.sendKeys(username);
    }
    public void enterPassword(){
        this.password.sendKeys(pass);
    }
    public void pressSubmitButton(){ this.login_button.click(); }

    //--------------------------------------------------//

    public void pressAddToCartButton(){
        this.add_to_cart_button.click();
    }
    public void pressCartButton(){
        this.open_cart.click();
    }
    public void pressCheckOutButton(){ this.check_out.click();}

    //--------------------------------------------------//

    public void enterFirstName(){ this.name_one.sendKeys(fname);}
    public void enterLastName(){ this.surname.sendKeys(fani);}
    public void enterPostCode(){ this.post_code.sendKeys(code);}
    public void pressContinueOn(){ this.cont.click();}

    public void pressFinish(){ this.finish.click();}
    public void clickFinishWord(){ this.done.click();}
}